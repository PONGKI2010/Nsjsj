token=''
domain=''
admin_id=[] #관리자 id
developer=''
