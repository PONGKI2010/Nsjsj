
import discord, sqlite3, os, random, asyncio, requests, json, time

client = discord.Client()


@client.event
async def on_ready():
    print(client.user)


@client.event
async def on_message_delete(message):
    if message.channel.id == 1102270783662870608:
        log = 1102270783662870608
        await client.get_channel(log).send(message.content)
client.run("MTEwNTQ3NTAzNTYxNzA1NDc5Mw.GWcOLZ.XEb4IuNr4jnKmXUT-G9WsdARbf2c2P7mi_MyMk")
